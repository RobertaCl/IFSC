function nome(){
    nome = window.prompt ("Digite seu nome!");
    alert ("Olá "+nome+", seja bem vindo! :)");
}