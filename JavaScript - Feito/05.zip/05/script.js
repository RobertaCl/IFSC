let nome = window.prompt ("Digite seu nome"); 
document.getElementById("nome").innerHTML = nome