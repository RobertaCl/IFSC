function onButton(){
    alert ("Você clicou no botão!"); 
}