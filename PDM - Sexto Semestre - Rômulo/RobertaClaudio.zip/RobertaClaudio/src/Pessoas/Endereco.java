package Pessoas;
public class Endereco {
		public String nomeCidade;
		public String rua;
		public int numero;
		
		public String getNomeCidade() {
			return nomeCidade;
		}
		public void setNomeCidade(String nomeCidade) {
			this.nomeCidade = nomeCidade;
		}
		public String getRua() {
			return rua;
		}
		public void setRua(String rua) {
			this.rua = rua;
		}
		public int getNumero() {
			return numero;
		}
		public void setNumero(int numero) {
			this.numero = numero;
		}
}