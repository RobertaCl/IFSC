package Pessoas;
public class Main {

	public static void main(String[] args) {
		
			Endereco E = new Endereco();
			Pessoa P = new Pessoa ();
			E.setNomeCidade("Blumenau");
			E.setNumero(197);
			E.setRua("Sete de Setembro");
			P.setEmail("roberta.c04@aluno.ifsc.edu.br");
			P.setNome("Roberta");
			P.setTelefone(1234567789);
			P.setEndereco(E);
			
			System.out.println(P.getEndereco());
			System.out.println(P);
	}
}
