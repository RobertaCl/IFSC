package Formas;
abstract class Forma {
    public double Area;
    public double Perimetro;

    public double getArea() {
        return Area;
    }
    public void setArea(double area) {
        Area = area;
    }
    public double getPerimetro() {
        return Perimetro;
    }
    public void setPerimetro(double perimetro) {
        Perimetro = perimetro;
    }
}