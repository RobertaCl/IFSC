package Formas;
public class Retangulo extends Forma {
    public double Alt;
    public double Larg;
    
    public double getAlt() {
        return Alt;
    }
    public void setAlt(double alt) {
        Alt = alt;
    }
    public double getLarg() {
        return Larg;
    }
    public void setLarg(double larg) {
        Larg = larg;
    }

    public double Area(){
        return Alt * Larg;
    }

    @Override
    public double getArea() {
        return Area();
    }
}

