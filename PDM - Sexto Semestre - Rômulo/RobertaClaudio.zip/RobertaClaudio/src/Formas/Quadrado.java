package Formas;
public class Quadrado extends Retangulo {
    public double Lado;

	public double getLado() {
		return Lado;
	}

	public void setLado(double lado) {
		Lado = lado;
	}
    public double Area(){
        return Lado * Lado;
    }

    @Override
    public double getArea() {
        return Area();
    }
}
