package Formas;
public class Circulo extends Forma {
	public double Raio;

	public double getRaio() {
		return Raio;
	}
	public void setRaio(double raio) {
		Raio = raio;
	}
    public double Area(){
        return 3.14*(Raio*Raio);
    }
    @Override
    public double getArea() {
        return Area();
    }
    public double Perimetro(){
        return 3.14*2*Raio;
    }
    @Override
    public double getPerimetro() {
        return Perimetro();
    }
}