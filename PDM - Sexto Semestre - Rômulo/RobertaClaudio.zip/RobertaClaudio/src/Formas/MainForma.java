package Formas;
public class MainForma {
    public static void main(String[] args) {

        Retangulo r = new Retangulo();
        r.setLarg(5);
        r.setAlt(3);
        System.out.println(r.getArea());
        
        Circulo c = new Circulo();
        c.setRaio(2);
        c.getArea();
        c.getPerimetro();
        System.out.println(c.getArea());
        System.out.println(c.getPerimetro());
        
        Quadrado q = new Quadrado();
        q.setLado(2);
        System.out.println(q.getArea());
    }
}
