package ifsc.claudio.slideshow;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList Lst = new ArrayList();
    ImageView img;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView) findViewById(R.id.imageView);
        i = 0;

        Lst.add(R.drawable.patinho);
        Lst.add(R.drawable.porquinho);
        Lst.add(R.drawable.gardem);
        Lst.add(R.drawable.happy);
        Lst.add(R.drawable.cachorro);
    }

    public void proximoimg(View v){
        i++;
        if (i == Lst.size()){
            i = 0;
            img.setImageResource((Integer) Lst.get(i));
        } else
        {
            img.setImageResource((Integer) Lst.get(i));
        }
    }

    public void anterior(View v){
        i--;
        if (i < 0){
            i = Lst.size() - 1;
            img.setImageResource((Integer) Lst.get(i));
        } else
        {
            img.setImageResource((Integer) Lst.get(i));
        }
    }
}