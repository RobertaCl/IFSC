package ifsc.claudio.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    livros livro1 = new livros("Enquanto eu nao te encontro", R.drawable.encontro , "Pedro Rhuas");
    livros livro2 = new livros("Até o Verão Terminar", R.drawable.collen , "Collen Hoover");
    livros livro3 = new livros("Os Sete Maridos de Evelyn Hugo", R.drawable.evelyn ,"Taylor Jenkins Reid");
    livros [] livros = new livros[] {livro1, livro2, livro3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.listView);

        MeuArrayAdapter myadapter = new MeuArrayAdapter(
                getApplicationContext(),
                R.layout.item_lista,
                livros
        );

        listView.setAdapter(myadapter);

    }
}