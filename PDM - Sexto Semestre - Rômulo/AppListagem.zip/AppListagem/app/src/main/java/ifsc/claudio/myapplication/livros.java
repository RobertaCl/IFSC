package ifsc.claudio.myapplication;

public class livros {
    public String nome;
    public int Capa;
    public String Autor;

    public livros(String nome, int Capa, String Autor) {
        this.nome = nome;
        this.Capa = Capa;
        this.Autor = Autor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCapa() {
        return Capa;
    }

    public void setCapa(int Capa) {
        this.Capa = Capa;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String Autor) {
        this.Autor = Autor;
    }
}
