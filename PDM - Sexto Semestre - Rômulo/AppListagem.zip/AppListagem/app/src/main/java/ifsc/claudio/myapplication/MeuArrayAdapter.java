package ifsc.claudio.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MeuArrayAdapter extends ArrayAdapter {
    Context mycontext;
    int myresource;
    public MeuArrayAdapter(@NonNull Context context, int resource, @NonNull Object[] objects) {
        super(context, resource, objects);
        mycontext = context;
        myresource = resource;
    }

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mycontext);
        @SuppressLint("ViewHolder") View view = inflater.inflate(myresource, parent,false);
        TextView nome = view.findViewById(R.id.textView2);
        ImageView imagem = view.findViewById(R.id.imageView);
        TextView Autor = view.findViewById(R.id.textView);
        livros Livro = (livros) getItem(position);
        nome.setText("Nome: " + Livro.getNome());
        Autor.setText("Autor: " + Livro.getAutor());
        imagem.setImageResource(Livro.Capa);
        return view;
    }
}
