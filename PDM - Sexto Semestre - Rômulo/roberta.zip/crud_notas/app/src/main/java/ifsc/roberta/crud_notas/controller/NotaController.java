package ifsc.roberta.crud_notas.controller;

import android.content.Context;

import java.util.ArrayList;

import ifsc.roberta.crud_notas.model.Nota;
import ifsc.roberta.crud_notas.model.NotaDao;

public class NotaController {

    Context context;
    NotaDao notaDao;

    public NotaController(Context context) {
        this.context = context;
        notaDao = new NotaDao(context);
    }

    public Nota createNota(Nota n) {
        return notaDao.createNota(n);
    }

    public ArrayList<Nota> getListaNotas() {
        return notaDao.getListaNotas();
    }

    public void updateNota(Nota nota) {
        notaDao.updateNota(nota);
    }

    public void deleteNota(Integer id) {
        notaDao.deleteNota(id);
    }
}