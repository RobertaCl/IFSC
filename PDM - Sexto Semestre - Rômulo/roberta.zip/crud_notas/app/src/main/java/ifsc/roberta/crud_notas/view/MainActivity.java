package ifsc.roberta.crud_notas.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import ifsc.roberta.crud_notas.R;
import ifsc.roberta.crud_notas.controller.NotaController;
import ifsc.roberta.crud_notas.model.AdapterNota;
import ifsc.roberta.crud_notas.view.CriarNota;

public class MainActivity extends AppCompatActivity {

    ListView listagemNotas;
    NotaController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listagemNotas = findViewById(R.id.listNotas);
    }

    public void createNota(View v) {
        Intent intent = new Intent(this, CriarNota.class);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        controller = new NotaController(getApplicationContext());

        AdapterNota notaAdapter = new AdapterNota(
                getApplicationContext(),
                R.layout.item_nota,
                controller.getListaNotas()
        );

        listagemNotas.setAdapter(notaAdapter);
    }

}