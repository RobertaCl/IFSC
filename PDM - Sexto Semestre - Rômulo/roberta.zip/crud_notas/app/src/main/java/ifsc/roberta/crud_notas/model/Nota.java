package ifsc.roberta.crud_notas.model;

import java.io.Serializable;

public class Nota implements Serializable {

    Integer id;
    String titulo;
    String desc;

    public Nota(Integer id, String titulo, String desc) {
        this.id = id;
        this.titulo = titulo;
        this.desc = desc;
    }

    public Nota(String titulo, String desc) {
        this.titulo = titulo;
        this.desc = desc;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}