package ifsc.roberta.crud_notas.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import ifsc.roberta.crud_notas.R;
import ifsc.roberta.crud_notas.controller.NotaController;
import ifsc.roberta.crud_notas.model.Nota;

public class CriarNota extends AppCompatActivity {

    EditText txtTitulo, txtDesc;
    NotaController notaController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_nota);

        notaController = new NotaController(getApplication());

        txtTitulo = findViewById(R.id.txtTitulo);
        txtDesc = findViewById(R.id.txtDescricao);
    }

    public void criarNota(View v) {
        String nome = txtTitulo.getText().toString();
        String desc = txtDesc.getText().toString();

        notaController.createNota(new Nota(nome, desc));

        super.finish();
    }
}