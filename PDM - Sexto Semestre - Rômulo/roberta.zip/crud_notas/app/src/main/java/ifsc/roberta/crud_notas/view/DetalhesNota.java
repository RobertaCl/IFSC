package ifsc.roberta.crud_notas.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import ifsc.roberta.crud_notas.R;
import ifsc.roberta.crud_notas.controller.NotaController;
import ifsc.roberta.crud_notas.model.Nota;

public class DetalhesNota extends AppCompatActivity {

    NotaController notaController;
    EditText titulo, descricao;
    Nota nota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_nota);

        titulo = findViewById(R.id.txtTitulo);
        descricao = findViewById(R.id.txtDescricao);

        nota = (Nota) getIntent().getSerializableExtra("NOTA");

        titulo.setText(nota.getTitulo());
        descricao.setText(nota.getDesc());

    }

    public void updateNota(View v) {
        notaController = new NotaController(getApplicationContext());
        notaController.updateNota(new Nota(nota.getId(), titulo.getText().toString(), descricao.getText().toString()));
        super.finish();
    }

    public void deleteNota(View v) {
        notaController = new NotaController(getApplicationContext());
        notaController.deleteNota(nota.getId());
        super.finish();
    }
}