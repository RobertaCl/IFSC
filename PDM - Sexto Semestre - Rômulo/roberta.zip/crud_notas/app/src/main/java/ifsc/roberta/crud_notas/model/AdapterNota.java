package ifsc.roberta.crud_notas.model;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

import ifsc.roberta.crud_notas.R;
import ifsc.roberta.crud_notas.view.DetalhesNota;

public class AdapterNota extends ArrayAdapter {

    int resource;
    Context context;
    ArrayList<Nota> notas;

    public AdapterNota(Context c, int resource, ArrayList<Nota> notas) {
        super(c, resource, notas);
        this.context = c;
        this.resource = resource;
        this.notas = notas;
    }

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(context);

        @SuppressLint("ViewHolder") View view = inflater.inflate(resource, parent,false);

        TextView nome = view.findViewById(R.id.txtNome);
        TextView descricao = view.findViewById(R.id.txtDescricao);

        Nota nota = (Nota) notas.get(position);

        nome.setText(nota.getTitulo());
        descricao.setText(nota.getDesc());

        view.findViewById(R.id.btnDetalhes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetalhesNota.class);

                Nota nota = notas.get(position);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("NOTA", nota);

                getContext().getApplicationContext().startActivity(intent);
            }
        });

        return view;
    }

}