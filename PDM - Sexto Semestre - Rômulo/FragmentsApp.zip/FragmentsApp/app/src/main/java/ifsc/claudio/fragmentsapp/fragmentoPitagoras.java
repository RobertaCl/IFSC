package ifsc.claudio.fragmentsapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class fragmentoPitagoras extends Fragment {

        EditText cateto1;
        EditText cateto2;
        TextView resultadoF;
        Button btnCalculo;

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

            // return super.onCreateView(inflater, container, savedInstanceState);
            View view = inflater.inflate(R.layout.fragments_pitagoras, container, false);

            cateto1 = view.findViewById(R.id.txtCat1);
            cateto2 = view.findViewById(R.id.txtCat2);
            resultadoF = view.findViewById(R.id.lblResult);
            btnCalculo = view.findViewById(R.id.btnCalc);
            btnCalculo.setOnClickListener(botaoClickListener);

            return view;
        }
        private final View.OnClickListener botaoClickListener = new View.OnClickListener() {
            public void onClick(View v) {
                calcularPit();
            }
        };

        public double calculaHipotenusa(float cateto1, float cateto2) {
        return   Math.sqrt(Math.pow(cateto1, 2) + Math.pow(cateto2, 2));

        }

        public void calcularPit(){

            float vCat1 = Float.parseFloat(cateto1.getText().toString());
            float vCat2 = Float.parseFloat(cateto2.getText().toString());

            double resultado = calculaHipotenusa(vCat1, vCat2);

            resultadoF.setText("Valor: " + resultado);
        }
}
