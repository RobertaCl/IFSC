package ifsc.claudio.imcapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText ps;
    EditText alt;
    EditText nome;
    Button btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ps = (EditText) findViewById(R.id.ps);
        alt = (EditText) findViewById(R.id.alt);
        nome = (EditText) findViewById(R.id.nome);
        btn = (Button) findViewById(R.id.btn);
    }

    public void Click(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivityDois.class);
        intent.putExtra("PESO", ps.getText().toString());
        intent.putExtra("ALTURA", alt.getText().toString());
        intent.putExtra("NOME", nome.getText().toString());
        startActivity(intent);
        finish();
    }
}