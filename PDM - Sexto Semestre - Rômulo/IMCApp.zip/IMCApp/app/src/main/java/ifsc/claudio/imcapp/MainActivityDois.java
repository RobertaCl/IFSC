package ifsc.claudio.imcapp;

import android.icu.text.IDNA;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivityDois extends AppCompatActivity {

    TextView InfoPs;
    TextView InfoAlt;
    TextView InfoImc;
    TextView InfoNome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maindois);

        InfoImc = (TextView) findViewById(R.id.imcInfo);
        InfoPs = (TextView) findViewById(R.id.peso);
        InfoAlt = (TextView) findViewById(R.id.altura);
        InfoNome = (TextView) findViewById(R.id.name);

        String valor = getIntent().getStringExtra("peso");
        String valor2 = getIntent().getStringExtra("altura");
        String nome = getIntent().getStringExtra("nome");

        Double peso = Double.parseDouble(valor);
        Double altura = Double.parseDouble(valor);
        Double res = peso/(altura * altura);

        InfoImc.setText("Seu IMC é: " + String.format("%.2f", res));
        InfoPs.setText("Peso: " + valor);
        InfoAlt.setText("Altura: " + valor);
        InfoNome.setText("Nome: " + nome);

        ImageView image = findViewById(R.id.imageView);

        if (res <= 18.5){
            image.setImageResource(R.drawable.muitoabaixo);
        } else
        if (res > 18.5 & res < 25 ){
            image.setImageResource(R.drawable.abaixodopeso);
        } else
        if (res >= 25 & res < 30 ){
            image.setImageResource(R.drawable.pesonormal);
        } else
        if (res >= 30 & res < 35 ){
            image.setImageResource(R.drawable.obs1);
        } else
        if (res >= 25 & res < 40 ){
            image.setImageResource(R.drawable.obs2);
        } else
        if (res > 40) {
            image.setImageResource(R.drawable.obs3);
        }
    }
}