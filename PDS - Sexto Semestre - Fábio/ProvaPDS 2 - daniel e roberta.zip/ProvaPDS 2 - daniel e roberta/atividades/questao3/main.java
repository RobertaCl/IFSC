package questao3;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField txtValor;
	private JTextField txtMa;
	private JTextField txtMd;
	private JTextField txtMe;
	public ArrayList<Double> valLista = new ArrayList<Double>();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public main() {
		setTitle("Números");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 277, 253);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Digite os valores:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 125, 19);
		contentPane.add(lblNewLabel);
		
		txtValor = new JTextField();
		txtValor.setBounds(145, 11, 89, 20);
		contentPane.add(txtValor);
		txtValor.setColumns(10);
		
		JButton bntAdicionar = new JButton("ADICIONAR");
		bntAdicionar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				double valor = Double.parseDouble(txtValor.getText());
				valLista.add(valor);
				txtValor.setText("");
			}
		});
		
		bntAdicionar.setFont(new Font("Tahoma", Font.BOLD, 11));
		bntAdicionar.setBounds(71, 41, 116, 23);
		contentPane.add(bntAdicionar);
		
		txtMa = new JTextField();
		txtMa.setEditable(false);
		txtMa.setColumns(10);
		txtMa.setBounds(92, 107, 142, 20);
		contentPane.add(txtMa);
		
		txtMd = new JTextField();
		txtMd.setEditable(false);
		txtMd.setColumns(10);
		txtMd.setBounds(92, 138, 142, 20);
		contentPane.add(txtMd);
		
		txtMe = new JTextField();
		txtMe.setEditable(false);
		txtMe.setColumns(10);
		txtMe.setBounds(92, 76, 142, 20);
		contentPane.add(txtMe);
		
		JLabel lblNewLabel_1 = new JLabel("Maior:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(12, 106, 76, 20);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Média:");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(12, 137, 76, 20);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Menor:");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_2.setBounds(10, 75, 76, 20);
		contentPane.add(lblNewLabel_1_2);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				double soma = 0;
				double Mm = -9999990.0;
				double Mn = 9999999.0;
				double Md = 0;
				
				
				for(int i = 0; i < valLista.size(); i++) {
					
					double valor = valLista.get(i);
					
					if(valor < Mn) {
						Mn = valor;
					}
					
					if(valor > Mm) {
						Mm = valor;
					}
					
					soma += valor;
				}
				
				Md = soma / valLista.size();
				
				
				txtMa.setText(Mm+"");
				txtMe.setText(Mn+"");
				txtMd.setText(Md+"");
				
				registrar_BD(Mm, Mn, Md);
				valLista.clear();
				
			}
		});
		
		btnCalcular.setBounds(36, 181, 182, 23);
		contentPane.add(btnCalcular);
	}
	
	public void registrar_BD(double Mm, double Mn, double Md) {
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/atividades", "root", "aluno");
			PreparedStatement ps = conn.prepareStatement("insert into numeros(Mm, Mn, Md) values(?, ?, ?)");
			ps.setDouble(1, Mm);
			ps.setDouble(2, Mn);
			ps.setDouble(3, Md);		
			
			ps.executeUpdate();
			
			System.out.println("Finalizado!");
			
		} catch (Exception ex) {
			System.out.println("Erro: " + ex);
		
		}
	}

}
