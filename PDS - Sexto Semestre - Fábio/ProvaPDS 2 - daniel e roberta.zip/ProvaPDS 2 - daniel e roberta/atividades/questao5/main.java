package questao5;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Canvas;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField txtLD1;
	private JTextField txtLD2;
	private JTextField txtLD3;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public main() {
		setTitle("Triângulos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 261, 407);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblLD1 = new JLabel("Lado 1");
		lblLD1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLD1.setBounds(10, 11, 58, 20);
		contentPane.add(lblLD1);
		
		txtLD1 = new JTextField();
		txtLD1.setBounds(78, 12, 151, 20);
		contentPane.add(txtLD1);
		
		txtLD2 = new JTextField();
		txtLD2.setBounds(78, 43, 151, 20);
		contentPane.add(txtLD2);
		
		JLabel lblLD2 = new JLabel("Lado 2");
		lblLD2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLD2.setBounds(10, 42, 58, 20);
		contentPane.add(lblLD2);
		
		txtLD3 = new JTextField();
		txtLD3.setBounds(78, 75, 151, 20);
		contentPane.add(txtLD3);
		
		JLabel lblLD3 = new JLabel("Lado 3");
		lblLD3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLD3.setBounds(10, 74, 58, 20);
		contentPane.add(lblLD3);
		
		JLabel lblIMG = new JLabel("");
		lblIMG.setHorizontalAlignment(SwingConstants.CENTER);
		lblIMG.setIcon(new ImageIcon("C:\\Users\\Aluno\\Downloads\\Prova2 Pds\\Prova Pds\\Atividade5 Triangulos\\Atividade5\\src\\triangulos.jpg"));
		lblIMG.setBounds(10, 157, 219, 168);
		contentPane.add(lblIMG);
		
		ImageIcon imagem = new ImageIcon(getClass().getResource("triangulos2.jpg"));
		lblIMG.setIcon(imagem);
		
		JLabel lblRspt = new JLabel("*-*");
		lblRspt.setHorizontalAlignment(SwingConstants.CENTER);
		lblRspt.setBounds(37, 132, 180, 14);
		contentPane.add(lblRspt);
		
		JButton btnVerificar = new JButton("Verificar");
		btnVerificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					String pathImagem = "trian";
					
					
					double ld1 = Double.parseDouble(txtLD1.getText());
					double ld2 = Double.parseDouble(txtLD2.getText());
					double ld3 = Double.parseDouble(txtLD3.getText());
					String resp = "";
					
					// operações matemáticas para verificar qual triângulo é
					
					if((ld1 + ld2) < ld3 || (ld2 + ld3) < ld1 || (ld1 + ld3) < ld2) {
						pathImagem = "error2.png";
						lblRspt.setText("Triangulo inválido! Tente Novamente");
						resp = "invalido";						
						
					}else if(ld1 == ld2 && ld2 == ld3) {
						pathImagem = "equilatero2.jpg";
						lblRspt.setText("Uau! Triangulo equilátero!");
						resp = "equilatero";	
						
					}else if(ld1 == ld2 || ld2 == ld3 || ld1 == ld3){
						pathImagem = "isoceles2.jpg";
						lblRspt.setText("Uau! Triangulo isóceles!");
						resp = "isoceles";
						
					}else {
						pathImagem = "escaleno2.jpg";
						lblRspt.setText("Uau! Triangulo escaleno!");
						resp = "escalena";
						
					}
					
					registrar_BD(ld1, ld2, ld3, resp);
					
					ImageIcon imagem = new ImageIcon(getClass().getResource(pathImagem));
					lblIMG.setIcon(imagem);
					
				}catch(Exception exception) {
					
					ImageIcon imagem = new ImageIcon(getClass().getResource("erro.png"));
					lblIMG.setIcon(imagem);
					
					lblRspt.setText("Por favor, digite todos os valores!");
				}
				
			}
		});
		btnVerificar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnVerificar.setBounds(10, 108, 89, 23);
		contentPane.add(btnVerificar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				txtLD1.setText("");
				txtLD2.setText("");
				txtLD3.setText("");
				
				ImageIcon imagem = new ImageIcon(getClass().getResource("tri.jpg"));
				lblIMG.setIcon(imagem);
				
			}
		});
		btnLimpar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnLimpar.setBounds(146, 337, 89, 20);
		contentPane.add(btnLimpar);
	}
	
	public void registrar_BD(double l1, double l2, double l3, String classificacao) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/atividades", "root", "aluno");
			PreparedStatement ps = conn.prepareStatement("insert into triangulos(l1, l2, l3, classificacao) values(?, ?, ?, ?)");
			ps.setDouble(1, l1);
			ps.setDouble(2, l2);
			ps.setDouble(3, l3);
			ps.setString(4, classificacao);
			
			ps.executeUpdate();
			
			System.out.println("Finalizado!");
			
		} catch (Exception ex) {
			System.out.println("Erro: " + ex);
		
		}
	}
}
