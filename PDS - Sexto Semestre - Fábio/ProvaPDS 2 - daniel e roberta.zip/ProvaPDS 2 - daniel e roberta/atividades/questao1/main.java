package questao1;

import java.awt.EventQueue;
import java.sql.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public main() {
		setTitle("É primo?");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 300, 458, 339);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Insira um número:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(123, 58, 200, 14);
		contentPane.add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(149, 104, 152, 26);
		contentPane.add(textField);
		textField.setColumns(10);

		JLabel lblCheck = new JLabel("");
		lblCheck.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblCheck.setHorizontalAlignment(SwingConstants.CENTER);
		lblCheck.setBounds(88, 232, 284, 22);
		contentPane.add(lblCheck);

		JButton btnNewButton = new JButton("Verificar se é primo ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int count = 0;
					int num = Integer.parseInt(textField.getText());
					for (int i = 1; i <= num; i++) {
						double verificar = num % i;
						if (verificar == 0) {
							count++;
						}
					}
					if (count == 2) {
						lblCheck.setText("O número " + num + " é um número primo");
						registrar_BD(num, "Sim");
					} else {
						lblCheck.setText("O número " + num + " não é um número primo");
						registrar_BD(num, "Não");
					}
				} catch (Exception ex) {
					lblCheck.setText("Digite um número!");
				}

			}
		});
		btnNewButton.setBounds(149, 152, 152, 34);
		contentPane.add(btnNewButton);
	}

	public void registrar_BD(int num, String res) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/atividades", "root", "aluno");
			PreparedStatement ps = conn.prepareStatement("insert into primo(numero, primo) values(?, ?)");
			ps.setInt(1, num);
			ps.setString(2, res);

			ps.executeUpdate();

			System.out.println("Finalizado");

		} catch (Exception ex) {
			System.out.println("Erro: " + ex);

		}
	}
}