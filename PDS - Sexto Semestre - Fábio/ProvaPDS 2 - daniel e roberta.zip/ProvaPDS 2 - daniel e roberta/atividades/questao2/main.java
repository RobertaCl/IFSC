package questao2;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

public class main extends JFrame {

	private JPanel contentPane;
	private JTextField txtVal1;
	private JTextField txtVal2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					main frame = new main();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public main() {
		setTitle("Operacoes Matematicas!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 430, 141);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Digite dois numeros:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(10, 11, 126, 19);
		contentPane.add(lblNewLabel);
		
		txtVal1 = new JTextField();
		txtVal1.setBounds(134, 11, 126, 20);
		contentPane.add(txtVal1);
		txtVal1.setColumns(10);
		
		txtVal2 = new JTextField();
		txtVal2.setBounds(270, 11, 126, 20);
		contentPane.add(txtVal2);
		txtVal2.setColumns(10);
		
		JLabel lblReslt = new JLabel("Resultado:");
		lblReslt.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblReslt.setBounds(10, 72, 243, 19);
		contentPane.add(lblReslt);
		
		JButton btnSomar = new JButton("Somar");
		btnSomar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					double v1 = Double.parseDouble(txtVal1.getText());
					double v2 = Double.parseDouble(txtVal2.getText());
					
					double Reslt = v1 + v2;
					
					lblReslt.setText("Reslt " + v1 + " + " + v2 + " = " + Reslt);
					registrar_BD(v1, v2, "soma", Reslt);
				}catch (Exception exception) {
					JOptionPane.showMessageDialog(btnSomar, "Insira dois valores válidos, por favor!");
				}
				
			}
		});
		
		btnSomar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSomar.setBounds(20, 41, 81, 23);
		contentPane.add(btnSomar);
		
		JButton btnMultiplicar = new JButton("Multiplicar");
		btnMultiplicar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					double v1 = Double.parseDouble(txtVal1.getText());
					double v2 = Double.parseDouble(txtVal2.getText());
					
					double Reslt = v1 * v2;
					
					lblReslt.setText("Reslt " + v1 + " x " + v2 + " = " + Reslt);
					registrar_BD(v1, v2, "multiplicacao", Reslt);
				}catch (Exception exception) {
					JOptionPane.showMessageDialog(btnSomar, "Insira dois valores válidos, por favor!");
				}
				
			}
		});
		
		btnMultiplicar.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnMultiplicar.setBounds(111, 41, 97, 23);
		contentPane.add(btnMultiplicar);
		
		JButton btnSubtrair = new JButton("Subtrair");
		btnSubtrair.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnSubtrair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					double v1 = Double.parseDouble(txtVal1.getText());
					double v2 = Double.parseDouble(txtVal2.getText());
					
					double Reslt = v1 - v2;
					
					lblReslt.setText("Reslt " + v1 + " - " + v2 + " = " + Reslt);
					registrar_BD(v1, v2, "subtracao", Reslt);
				}catch (Exception exception) {
					JOptionPane.showMessageDialog(btnSomar, "Insira dois valores válidos, por favor!");
				}
				
			}
		});
		
		btnSubtrair.setBounds(218, 42, 89, 23);
		contentPane.add(btnSubtrair);
		
		
		JButton btnDividir = new JButton("Dividir");
		btnDividir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					double v1 = Double.parseDouble(txtVal1.getText());
					double v2 = Double.parseDouble(txtVal2.getText());
					
					double Reslt = v1 / v2;
					
					lblReslt.setText("Reslt " + v1 + " / " + v2 + " = " + Reslt);
					registrar_BD(v1, v2, "divisao", Reslt);
				}catch (Exception exception) {
					JOptionPane.showMessageDialog(btnSomar, "Insira dois valores válidos, por favor!");
				}
				
			}
		});
		
		btnDividir.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnDividir.setBounds(317, 42, 81, 23);
		contentPane.add(btnDividir);
		
	}
	
	public void registrar_BD(double v1, double v2, String op, double soma) {
		try {
			
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/atividades", "root", "aluno");
			PreparedStatement ps = conn.prepareStatement("insert into calcular(numero1, numero2, op, resultado) values(?, ?, ?, ?)");
			ps.setDouble(1, v1);
			ps.setDouble(2, v2);
			ps.setString(3, op);
			ps.setDouble(4, soma);
			
			ps.executeUpdate();
			
			System.out.println("Finalizado!");
			
		} catch (Exception ex) {
			System.out.println("Erro: " + ex);
		
		}
	}
}
