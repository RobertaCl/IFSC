package questao4;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JLabel;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtResultado;
	private JTextField txtTexto;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setTitle("Inverter");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 332);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		txtTexto = new JTextField();
		txtTexto.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtTexto.setColumns(10);
		txtTexto.setBounds(87, 84, 189, 29);
		contentPane.add(txtTexto);

		txtResultado = new JTextField();
		txtResultado.setFont(new Font("Tahoma", Font.PLAIN, 14));
		txtResultado.setEditable(false);
		txtResultado.setBounds(87, 142, 189, 29);
		contentPane.add(txtResultado);
		txtResultado.setColumns(10);

		JButton btnInverter = new JButton("Inverter");
		btnInverter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				final String texto = txtTexto.getText();

				char[] arrayTexto = texto.toCharArray();

				String resultado = "";

				int index = texto.length() - 1;

				for (int i = index; i >= 0; i--) {
					resultado += arrayTexto[i];
				}

				txtResultado.setText(resultado);

				registrar_BD(texto, resultado);

			}
		});
		btnInverter.setBounds(118, 199, 127, 37);
		contentPane.add(btnInverter);

		JLabel lblNewLabel = new JLabel("Insira um texto para inverter");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(87, 44, 189, 29);
		contentPane.add(lblNewLabel);
	}

	public void registrar_BD(String texto, String resultado) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/atividades", "root", "aluno");
			PreparedStatement ps = conn.prepareStatement("insert into inverter(texto, textoAoContrario) values(?, ?)");
			ps.setString(1, texto);
			ps.setString(2, resultado);

			ps.executeUpdate();

			System.out.println("Finalizado");

		} catch (Exception ex) {
			System.out.println("Erro: " + ex);

		}
	}
}