package Exercicio1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {	
		
		ArrayList<Produto> listaProdutos = new ArrayList<Produto>();
		boolean repetir = true;
		int opcao;
		
		Produto p1 = new Produto(1, "Leite", 5.1, 24);
		Produto p2 = new Produto(2, "Café", 12.9, 10);
		Produto p3 = new Produto(3, "Açucar", 5.65, 20);
		Produto p4 = new Produto(4, "Feijão", 8.99, 16);
		Produto p5 = new Produto(5, "Macarrão", 12.34, 8);
		
		listaProdutos.add(p1);
		listaProdutos.add(p2);
		listaProdutos.add(p3);
		listaProdutos.add(p4);
		listaProdutos.add(p5);
		
		do
		{
			
			System.out.println("1. Cadastrar um novo produto");
			System.out.println("2. Consultar as informações sobre um produto");
			System.out.println("3. Vender um produto");
			System.out.println("4. Sair");
		
			Scanner s = new Scanner(System.in);
			opcao = Integer.parseInt(s.nextLine());
			
			switch(opcao)
			{
			case 1: 
				
				Produto p = new Produto();
				System.out.println("Qual o código do produto?");
				p.setCodigo(Integer.parseInt(s.nextLine()));
				System.out.println("Qual o nome do produto?");
				p.setNome(s.nextLine());
				System.out.println("Qual o preço do produto?");
				p.setPreco(Double.parseDouble(s.nextLine()));
				System.out.println("Qual a quantidade em estoque do produto?");
				p.setEstoque(Integer.parseInt(s.nextLine()));
				listaProdutos.add(p);
				break;
				
			case 2: 
				System.out.println("Qual o código do produto?");
				int produto_consultar = Integer.parseInt(s.nextLine());

				for (Produto pp : listaProdutos)
				{
					if (pp.getCodigo() == produto_consultar)
					{
						pp.MostrarDados();
						break;
					}
				}
				break;
			case 3:
				System.out.println("Qual o código do produto?");
				int codProduto = Integer.parseInt(s.nextLine());
				
				System.out.println("Qual a quantidade vendida?");
				int quantidadeVendida = Integer.parseInt(s.nextLine());
				
				for (Produto pp : listaProdutos)
				{
					if (pp.getCodigo() == codProduto)
					{
						if (quantidadeVendida <= pp.getEstoque()) {
							int estoque = (pp.getEstoque()-quantidadeVendida);
							pp.setEstoque(estoque);
							System.out.println("Produto vendido com sucesso!");
						} else {
							System.out.println("Não há produtos suficientes em estoque");
						}
					}
				}
				break;
			case 4:
				repetir = false;
				break;
			default:
				System.out.println("Opção não existe! Nota ZERO!!");
			}
		} while (repetir);
	}
		
}
