<?php
function f($a = 0){
    $a -= 1;
    echo $a.'/';
}

function j(&$a){
    $a--;
    echo $a.'/';
}

$i = 0;
f($i);
echo ($i.'/');
j($i);
echo ($i.'/');
?>