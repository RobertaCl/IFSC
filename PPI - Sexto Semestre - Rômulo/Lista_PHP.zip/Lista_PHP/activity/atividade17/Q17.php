<?php

    function verificarPalindromo($palavra){
        $palindromo = strrev($palavra);

        if ($palindromo == $palavra){
            echo ("É palíndromo");
            echo('<br>');
        } else {
            echo ("Não é palíndromo");
            echo('<br>');
        }

        return $palindromo;
    }

    $palavra = 'cachaça';
    echo verificarPalindromo($palavra);
    
?>