<?php

class Pessoa{

    protected $nome;
    protected $dataNasc;
    protected $Ps;
    protected $Alt;
    protected $Genr;

    public function setNome($nome){
        $this->nome = $nome;
     }
     public function getNome(){
        return $this->nome;
     }


     public function setNascimento($dataNasc){
        $this->dataNasc = $dataNasc;
     }
     public function getNascimento(){
        return $this->dataNasc;
     }


     public function setPs($Ps){
        $this->Ps = $Ps;
     }
     public function getPs(){
        return $this->Ps;
     }


     public function setAlt($Alt){
        $this->Alt = $Alt;
     }
     public function getAlt(){
        return $this->Alt;
     }


     public function setGenr($Genr){
        $this->Genr = $Genr;
     }
     public function getGenr(){
        return $this->Genr;
     }
}

?>