<?php

echo '<form method="get">';
    echo '<input type="text" name="Texto" value="get">';
    echo '<input type="hidden" name="acao" value="get">';
    echo '<input type="submit" value="GET">';
echo '</form>';

echo '<form method="post">';
    echo '<input type="text" name="Texto" value="post">';
    echo '<input type="hidden" name="acao" value="post">';
    echo '<input type="submit" value="POST">';
echo '</form>';

echo "Os valores passados via GET são: "
   . $_SERVER['QUERY_STRING'];
echo '<br>';

echo '<br>';
echo 'valores passados por post';
echo '<br>';
print_r($_POST);
?>
