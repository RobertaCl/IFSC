
<?php

echo "Ola ".$_POST ["nome"]." bem vindo";
echo "<br>";
echo "Digite suas informações";

session_start();

$_SESSION["nome"] = $_POST ["nome"];

?>

<form action="p3.php" method="get">
    <p> Seu peso </p>
    <input name="peso" type="text">
    <p> Sua altura </p>
    <input name="altura" type="text">
    <input type="submit">
</form>

