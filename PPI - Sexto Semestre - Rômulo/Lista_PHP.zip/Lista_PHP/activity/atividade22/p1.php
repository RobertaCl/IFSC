
<form action="p2.php" method="post">
    <p>Nome</p>
    <input name="nome" type="text">
    <input type="submit">
</form>