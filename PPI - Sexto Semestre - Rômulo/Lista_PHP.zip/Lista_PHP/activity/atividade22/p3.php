
<?php

    session_start();

    echo "Seu nome é: ".$_SESSION['nome'];
    echo "<br>";
    echo "Peso: ".$_GET ["peso"];
    echo "<br>";
    echo "Altura: ".$_GET ["altura"];
    echo "<br>";

    echo "IMC: ".$_GET ["peso"] / ($_GET ["altura"] * $_GET ["altura"]);

    session_destroy();

?>