<?php

    require_once "../atividade6/Q6.php";

    $array = f(5);
    $a = array_reverse($array);
    echo('<br>');
    print_r($a);

?>