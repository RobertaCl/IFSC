<?php

    require_once "../atividade6/Q6.php";

    function inter($array1, $array2){
        $array = array();
        $c = 0;
        for ($i=0; $i < count($array1); $i++){
                $array[$c] = $array1[$i];
                $c++;
                $array[$c] = $array2[$i];
                $c++;
            }
        return $array;
    }

    $a = f(7);
    echo("<br>");
    $b = f(7);
    echo("<br>");
    print_r (inter($a, $b));

?>