<?php

$ints = 1;
$strings = "string";
$doubles = 2.50; 
$bools= false;
$nulls = null;

?>