<?php

$a = 1;
$b = 2;
$ternario = $a + $b == 4 ? 'verdadeiro' : 'falso';

echo $ternario;

?>