<?php

    $numero1 = 3;
    $numero2 = 9;
    
    $igual = $numero1 == $numero2;
    $tiposiguais = $numero1 === $numero2;
    $menor = $numero1 < $numero2;
    $maior = $numero1 > $numero2;
    $maiorOUigual = $numero1 >= $numero2;
    $menorOUigual = $numero1 <= $numero2;
    $diferente = $numero1 != $numero2;
    
?>