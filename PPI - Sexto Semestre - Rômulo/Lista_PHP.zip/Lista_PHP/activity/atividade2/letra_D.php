<?php

$numero1 = 3;
$numero2 = 9;

$and = $numero1 && $numero2;
$or = $numero1 || $numero2;
$not = !$numero1;

echo "and: $and, or: $or, not: $not";

?>
