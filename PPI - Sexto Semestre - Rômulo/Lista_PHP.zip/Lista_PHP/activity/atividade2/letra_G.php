<?php

$nomeCompleto = '';

$nome = "Caue";
$nomeCompleto.= $nome;

$sobrenome = " Batista";
$nomeCompleto.= $sobrenome;

echo "Nome Completo: ". $nome . $sobrenome;
echo "<br>";
echo $nomeCompleto;
?>