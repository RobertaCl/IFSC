<?php

$num1 = 3;
$num2 = 9;

echo "incremento:". $num1++;
echo "<br>";
echo "decremento". $num2--; 

?>