<!DOCTYPE html>
<html>
    <body>
        <form action="index_j.php" method="get">
            <br>
            <input type="number" name='numero'>
            <input type="submit">
        </form>
            <?php
                echo $_GET['numero'];
            ?>
    </body>
</html>