<?php

$var1=10;

$var2= $var1;
 
$var2 -= 2; // igual var2=var2-2 
$var2 += 2; // igual var2=var2+2 
$var2 *= 2; // igual var2=var2*2 
$var2 /= 4; // igual var2=var2/2

echo "Antes:".$var1."<br>";
echo "Depois:". $var2;

?>