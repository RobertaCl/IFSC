<?php

$numero1 = 3;
$numero2 = 9;

$soma = $numero1 + $numero2;

$multiplicacao = $numero1 * $numero2;

$subtracao = $numero1 - $numero2;

$divisao = $numero1 / $numero2;

?>
