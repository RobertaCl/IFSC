<?php

    function inverteUrl($url){
        return strrev($url);
    }

    $url = "https://";   
    $url.= $_SERVER['HTTP_HOST'];   
    $url.= $_SERVER['REQUEST_URI'];    

    echo $url;
    echo "<br>";
    $urlInvertida = inverteUrl($url);
    echo $urlInvertida;  

?>