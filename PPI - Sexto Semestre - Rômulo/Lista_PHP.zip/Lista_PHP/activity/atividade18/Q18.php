<?php

    function calcularAreaRetangulo($Lado, $Alt){
        return $Lado * $Alt;
    }

    function calcularPerimetroRetangulo($Lado, $Alt){
        return ($Lado + $Alt) * 2;
    }
        
    function calcularAreaTriangulo($base, $Alt){ 
        return ($base * $Alt) / 2;
    }

    function calcularPerimetroTriangulo($Lado1, $Lado2, $Lado3 ){
        return $Lado1 + $Lado2 + $Lado3;
    }

    function calcularAreaCirculo($R){
        return pi()*($R * $R);
    }

    function calcularPerimetroCirculo($R){
        return (2*pi()) * $R;
    }

?>