<?php

echo '<form method="get">';
    echo '<input type="text" name="V1">';
    echo '<input type="text" name="V2">';
    echo '<input type="submit" value="Somar">';
echo '</form>';
echo '<br>';

if($_GET['V1'] == '' || $_GET['V2'] == ''){
    echo 'Por favor, escreva dois valores válidos!';
}else{
    echo $_GET['V1'] + $_GET['V2'];
}

?>
