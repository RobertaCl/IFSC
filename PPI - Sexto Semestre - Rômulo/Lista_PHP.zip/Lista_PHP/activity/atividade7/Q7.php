<?php
$num = $_GET['num'];
function f($num){
    $meuarray =array();
    for ($i=0; $i<$num; $i++){
        $meuarray[$i] = $i;
    }

    print_r ($meuarray);
    echo "Soma:".array_sum($meuarray);
    return;
}

f($num);

?>