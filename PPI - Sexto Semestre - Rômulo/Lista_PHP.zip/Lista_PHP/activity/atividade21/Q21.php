<?php

    if(isset ($_GET['acao']) && $_GET['acao'] == 'abrir'){
        session_start();
        $_SESSION['nome'] = $_GET['nome'];
        $_SESSION['id'] = $_GET['id'];
    }

    if(isset ($_GET['acao']) && $_GET['acao'] == 'fechar'){
        session_start();
        session_destroy();
    }


    if(isset($_SESSION['id'])){

        echo '<p> Sessão aberta </p>';
        echo 'Usuário: '.$_GET['nome'].'<br>';
        echo 'Id: '.$_GET['id'].'<br>';
        echo '<form method="get">';
        echo '<input type="hidden" name="acao" value="fechar">';
        echo '<input type="submit" value="fechar">';
        echo '</form>';

    }else{

        echo '<p> Sessão fechada </p>';
        echo '<form method="get">';
        echo 'Usuário:'.'<br>';
        echo '<input type="text" name="nome">'.'<br>';
        echo 'Id:'.'<br>';
        echo '<input type="number" name="id">'.'<br>';
        echo '<input type="hidden" name="acao" value="abrir">';
        echo '<input type="submit" value="abrir">';
        echo '</form>';

    }

?>

