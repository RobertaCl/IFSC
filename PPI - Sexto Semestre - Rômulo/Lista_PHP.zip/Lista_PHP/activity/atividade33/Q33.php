<?php

$navegadores = array('Firefox', 'Chrome', 'Safari', 'Opera GX'); 
$navegadorUsado = $_SERVER['HTTP_USER_AGENT'];


foreach($navegadores as $respNavegador)
{
    if(strrpos($navegadorUsado, $respNavegador))
    {
        $navegador = $respNavegador;
    }
}

echo "O navegador usado é: ".$navegador;

?>