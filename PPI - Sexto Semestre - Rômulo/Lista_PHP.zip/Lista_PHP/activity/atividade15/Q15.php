<?php

    $mapFruta = ["pera" => 4.50 , "uva" => 10.00 , "maça" => 5.00 ];
    //salada de frutas
    function somarFrutas ($map){
        $resultado = array_sum($map);
        return $resultado;
    }

    echo ("Resultado:".somarFrutas($mapFruta));

?>