<?php

class Contador
{
	// Propriedades da classe
	public $valor = 0;

    // Metodo da classe
    public function aumentar(){
        $this->valor++;
    }

    public function diminuir(){
        $this->valor--;
    }

    public function resetar(){
        $this->valor = 0;
    }

    public function setCount($valor){
        $this->valor = $valor;
     }
     public function getCount(){
        return $this->valor;
     }
}


?>