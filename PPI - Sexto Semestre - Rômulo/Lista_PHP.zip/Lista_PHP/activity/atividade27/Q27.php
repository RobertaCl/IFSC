<?php

class Pessoa{

    protected $nome;
    protected $dataNasc;
    protected $Ps;
    protected $Alt;
    protected $Genr;

    public function setNome($nome){
        $this->nome = $nome;
     }
     public function getNome(){
        return $this->nome;
     }


     public function setNascimento($dataNasc){
        $this->dataNasc = $dataNasc;
     }
     public function getNascimento(){
        return $this->dataNasc;
     }


     public function setPs($Ps){
        $this->Ps = $Ps;
     }
     public function getPs(){
        return $this->Ps;
     }


     public function setAlt($Alt){
        $this->Alt = $Alt;
     }
     public function getAlt(){
        return $this->Alt;
     }


     public function setGenr($Genr){
        $this->Genr = $Genr;
     }
     public function getGenr(){
        return $this->Genr;
     }
}

class HarrysBenedict{

    static function tbm($pessoa){

    $idade = 2022 - $pessoa->getNascimento();

    if($pessoa->getGenr() == 'masculino'){
        $caloria = 66.47 + (13.75 * $pessoa->getPs()) + (5 * $pessoa->getAlt()) - (6.76 - $idade);
        return $caloria;
    }else{
        $caloria = 655.1 + (9.56 * $pessoa->getPs()) + (1.85 * $pessoa->getAlt()) - (4.68 - $idade);
        return $caloria;
    }

    }
}

$objetoPessoa = new Pessoa;
$objetoHarrys = new HarrysBenedict;

$objetoPessoa->setNome('Caue');
$objetoPessoa->setNascimento(2004);
$objetoPessoa->setPs(82);
$objetoPessoa->setAlt(180);
$objetoPessoa->setGenr('masculino');

echo $objetoPessoa->getNome();
echo '<br>';
print_r($objetoHarrys->tbm($objetoPessoa));
?>