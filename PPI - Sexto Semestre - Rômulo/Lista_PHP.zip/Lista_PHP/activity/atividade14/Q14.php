<?php

    $mapPessoa = [
        "nome" => "João", 
        "idade" => "20",
        "telefone" => "(47) 9798-3032",
        "email" => "joão.ficticio@hotmail.com",
        "cpf" => "597.154.177-99",
        "endereco" => "Rua das palmeiras, blumenau"
    ];

    print_r($mapPessoa);

?>