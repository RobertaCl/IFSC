<?php

    function separarArray($palavra){
        $array = array();
        $array = explode(" ", $palavra);
        return $array;
    }

   $palavra = "O essência é invisível aos olhos...";

    print_r(separarArray($palavra));

?>