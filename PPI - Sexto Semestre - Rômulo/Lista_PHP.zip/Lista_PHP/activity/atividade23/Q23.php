<?php

session_start();

    if($_GET['acao'] == 'remover'){
        
        unset($_SESSION['valores'][$_GET['valor']]);
    }
    
    if($_GET['acao'] == 'adicionar'){
        
        array_push($_SESSION['valores'], $_GET['valor']);
     }
    
        echo '<form method="get">';
        echo '<p>Remover pelo indice do elemento</p>';
        echo '<input type="text" name="valor">';
        echo '<br>';
        echo '<input type="hidden" name="acao" value="remover">';
        echo '<input type="submit" value="remover">';
        echo '</form>';
      
        echo '<form method="get">';
        echo '<p>Adicionar elemento</p>';
        echo '<input type="text" name="valor">';
        echo '<br>';
        echo '<input type="hidden" name="acao" value="adicionar">';
        echo '<input type="submit" value="adicionar">';
        echo '</form>';
        echo '<br>';

        print_r($_SESSION['valores']);
?>


