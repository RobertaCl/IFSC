<?php

echo '<form method="get">';
    echo '<input type="text" name="text">';
    echo '<br>';
    echo '<input type="text" name="palavra">';
    echo '<input type="submit" value="procurar">';
echo '</form>';
echo '<br>';

if($_GET['text'] == '' || $_GET['palavra'] == ''){
    
    echo 'Preencha os dois campos';

}else{

    $texto = explode(' ', $_GET['text']);

    foreach($texto as $palavra){
        if(strcasecmp ($palavra, $_GET['palavra'])){
            echo $palavra.' ';
        }else{
            echo '<mark>'.$palavra.'</mark>'.' ';
        }
    }
}

?>