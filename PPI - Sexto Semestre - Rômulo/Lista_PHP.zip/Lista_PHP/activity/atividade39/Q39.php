<?php

echo '<form method="get">';
    echo '<input type="text" name="aniversario">';
    echo '<br>';
    echo '<p> formato do aniversario (dia - mes - ano) <p>';
    echo '<input type="submit" value="ver ID">';
echo '</form>';
echo '<br>';

$dataAtual = date('d-m-Y');
$aniversario = $_GET['aniversario'];

$ID = abs(strtotime($aniversario) - strtotime($dataAtual));

$An  = floor($ID / (365 * 60 * 60 * 24));

$MS = floor(($ID - $An * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));

$Ds   = floor(($ID - $An * 365 * 60 * 60 * 24 - $MS * 30 * 60 * 60 *24) / (60 * 60 * 24));

echo $An." year,  ".$MS." MS and ".$Ds." Ds";

?>