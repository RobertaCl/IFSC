<?php
    require_once "../atividade6/Q6.php";

    function maior ($array){
        $maior = $array[0];
        for($i=0; $i<count($array); $i++){
            if($array[$i] > $maior){
                $maior = $array[$i];
            }
        }
        echo($maior);
    }
    maior(f(5));
?>