<?php

echo '<form method="get">';
    echo '<input type="text" name="aniversario">';
    echo '<br>';
    echo '<p> formato do aniversario (dia - mes - ano) <p>';
    echo '<input type="submit" value="Ver data escrita">';
echo '</form>';
echo '<br>';

$dataEscritra = $_GET['aniversario'];
$data = strtotime($dataEscritra);

echo date("l, d F Y", $data);

?>