<?php
function f($num){
    $meuarray =array();
    for ($i=0; $i<$num; $i++){
        $meuarray[$i] = rand(0,10);
        
    }

    print_r ($meuarray);
    return $meuarray;
}

?>