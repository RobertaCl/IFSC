<?php

    require_once "../atividade6/Q6.php";

    function dois ($array1, $array2){
        $array3 = array_merge($array1, $array2);
        return $array3;
    }

    print_r (dois(f(5), f(5)));
?>