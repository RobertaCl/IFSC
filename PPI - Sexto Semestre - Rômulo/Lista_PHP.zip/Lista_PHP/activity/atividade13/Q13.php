<?php

    function separarArquivos($pasta) {

            $diretorio = dir($pasta);
            $i = 0;
            $array = array();
            
                while($arquivo = $diretorio -> read()){
                    $array[$i] = $arquivo;
                    $i++;
                }
            
            $diretorio -> close();
            return $array;
    }

    print_r(separarArquivos('C:/'));

?>