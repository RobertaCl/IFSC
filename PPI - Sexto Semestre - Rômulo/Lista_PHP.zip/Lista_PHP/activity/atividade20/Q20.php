<?php

    if(isset ($_GET['acao']) && $_GET['acao'] == 'abrir'){
        session_start();
        $_SESSION['nome'] = 'caue';
    }

    if(isset ($_GET['acao']) && $_GET['acao'] == 'fechar'){
        session_start();
        session_destroy();
    }


    if(isset($_SESSION['nome'])){

        echo '<p> Sessão aberta </p>';
        echo '<a href="quest20.php?acao=fechar"> fechar sessao </a>';

    }else{

        echo '<p> Sessão fechada </p>';
        echo '<a href="quest20.php?acao=abrir"> abrir sessao </a>';

    }

?>


