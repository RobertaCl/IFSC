<?php

class Pessoa{

    protected $nome;
    protected $Ps;
    protected $Alt;

    public function setNome($nome){
        $this->nome = $nome;
     }
     public function getNome(){
        return $this->nome;
     }


     public function setPs($Ps){
        $this->Ps = $Ps;
     }
     public function getPs(){
        return $this->Ps;
     }


     public function setAlt($Alt){
        $this->Alt = $Alt;
     }
     public function getAlt(){
        return $this->Alt;
     }

}

class IMC{
    static function calculaIMC($pessoa){
        $imc = $pessoa->getPs() / ($pessoa->getAlt() * $pessoa->getAlt());
        return $imc;
    }
}

$objetoPessoa = new Pessoa;
$objetoIMC = new IMC;

$objetoPessoa->setNome('Caue');
$objetoPessoa->setPs(82);
$objetoPessoa->setAlt(1.82);

echo $objetoPessoa->getNome();
echo '<br>';
print_r($objetoIMC->calculaIMC($objetoPessoa));

?>