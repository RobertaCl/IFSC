<?php
$num = $_GET['num'];
function f($num){
    $meuarray =array();
    for ($i=0; $i<$num; $i++){
        $meuarray[$i] = $i;
    }

    print_r ($meuarray);
    return;
}

f($num);

?>