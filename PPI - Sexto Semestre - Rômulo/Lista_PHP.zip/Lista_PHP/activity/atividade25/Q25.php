<?php

session_start();

class Contador
{
	// Propriedades da classe
	public $valor = 0;

    // Metodo da classe
    public function aumentar(){
        $this->valor++;
    }

    public function diminuir(){
        $this->valor--;
    }

    public function resetar(){
        $this->valor = 0;
    }

    public function setCount($valor){
        $this->valor = $valor;
     }
     public function getCount(){
        return $this->valor;
     }
}

if($_SESSION['contador'] == ''){
    $_SESSION['contador'] = new Contador;
}

echo '<form method="get">';
echo '<input type="hidden" name="acao" value="adicionar">';
echo '<input type="submit" value="adicionar">';
echo '</form>';

echo '<form method="get">';
echo '<input type="hidden" name="acao" value="diminuir">';
echo '<input type="submit" value="diminuir">';
echo '</form>';

echo '<form method="get">';
echo '<input type="hidden" name="acao" value="resetar">';
echo '<input type="submit" value="resetar">';
echo '</form>';

echo '<form method="get">';
echo '<input type="text" name="valor">';
echo '<input type="hidden" name="acao" value="definir">';
echo '<input type="submit" value="definir">';
echo '</form>';

if($_GET['acao'] == 'adicionar'){
    $_SESSION['contador']->aumentar();
}

if($_GET['acao'] == 'diminuir'){
    $_SESSION['contador']->diminuir();
 }
 
if($_GET['acao'] == 'resetar'){
    $_SESSION['contador']->resetar();
 }

 if($_GET['acao'] == 'definir'){
    $_SESSION['contador']->setCount($_GET['valor']);
    $_SESSION['contador']->getCount();
 }

// Acessando uma propriedade da classe
echo $_SESSION['contador']->valor;
?>