<?php
    include_once "PessoaDAO.php";

    class PessoaController{
        private $pessoa_dao;

        function __construct(){
            $this->pessoa_dao = new PessoaDAO();
        }

        function get_pessoa($id){
            $pessoa = $this->pessoa_dao->get_pessoa($id);
            return $pessoa;
        }

        function listar_pessoas(){
            $pessoas = $this->pessoa_dao->listar_pessoas();
            return $pessoas;
        }

        function excluir_pessoa($id){
            $this->pessoa_dao->excluir_pessoa($id);
        }

        function alterar_pessoa($id, $nome, $telefone, $email, $data_nasc){
            $this->pessoa_dao->alterar_pessoa($id, $nome, $telefone, $email, $data_nasc);
        }

        function cadastrar_pessoa($nome, $telefone, $email, $data_nasc){
            $this->pessoa_dao->cadastrar_pessoa($nome, $telefone, $email, $data_nasc);
        }

        function pesquisar_pessoas($nome){
            $pessoas = $this->pessoa_dao->pesquisar_pessoas($nome);
            return $pessoas;
        }
    }
?>