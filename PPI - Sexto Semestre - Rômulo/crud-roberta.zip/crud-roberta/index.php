<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style2.css">
    <title> Listagem de Pessoas </title>
</head>

<body>
    <form class="container-pesquisa" action="" method="POST">
        <input name="pesquisa" type="text" placeholder="Digite algo...">
       <input class="btn-pesquisar" type="text" name="pesquisa" id="pesquisa" value="Pesquisar">
    </form>
    <div class="container">
        <table class="tabela">
            <tr class="linha">
                <th class="clm cabecalho">
                    Código
                </th>
                <th class="clm">
                    Nome
                </th>
                <th class="clm">
                    Telefone
                </th>
                <th class="clm">
                    E-mail
                </th> 
                <th class="clm">
                    Data de Nascimento
                </th>
                <th class="clm">
                    Editar
                </th>
                <th class="clm">
                    Excluir
                </th>
            </tr>
            <?php
                session_start();
                if (!isset($_SESSION["islogged"]) || $_SESSION["islogged"] != "ok"){
                    header("Location: login.php");
                }
                include_once "PessoaController.php";
                include_once "Pessoa.php";
                $controller = new PessoaController();
                if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["pesquisa"])){
                    $nome = $_POST["pesquisa"];
                    $pessoas = $controller->pesquisar_pessoas($nome);
                    foreach($pessoas as $pessoa){
                        $id = $pessoa->get_id();
                        $nome = $pessoa->get_nome();
                        $telefone = $pessoa->get_telefone();
                        $email = $pessoa->get_email();
                        $data_nasc = $pessoa->get_data_nasc();
                        echo "
                        <tr class=\"linha\">
                            <td>$id</td>
                            <td>$nome</td>
                            <td>$telefone</td>
                            <td>$email</td>
                            <td>$data_nasc</td>
                            <td><a href=\"editar.php?id=$id\">Editar</a></td>
                            <td><a href=\"excluir.php?id=$id\">Excluir</a></td>
                        </tr>
                        ";
                    }
                }else {
                    $pessoas = $controller->listar_pessoas();
                    foreach($pessoas as $pessoa){
                        $id = $pessoa->get_id();
                        $nome = $pessoa->get_nome();
                        $telefone = $pessoa->get_telefone();
                        $email = $pessoa->get_email();
                        $data_nasc = $pessoa->get_data_nasc();
                        echo "
                        <tr>
                            <td>$id</td>
                            <td>$nome</td>
                            <td>$telefone</td>
                            <td>$email</td>
                            <td>$data_nasc</td>
                            <td><a href=\"editar.php?id=$id\">Editar</a></td>
                            <td><a href=\"excluir.php?id=$id\">Excluir</a></td>
                        </tr>
                        ";
                    }
                }
            ?>
        </table>
    </div>
    <div class="container-button">
        <div class="div-button">
            <a href="cadastrar.php">
                <button class="btn-cadastrar">
                    Cadastrar
                </button>
            </a>
        </div>      
    </div>
</body>
</html>