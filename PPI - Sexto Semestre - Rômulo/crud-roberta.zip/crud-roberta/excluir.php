<?php
    include_once "PessoaController.php";
    if (isset($_GET["id"])){
        $controller = new PessoaController();
        $controller->excluir_pessoa($_GET["id"]);
    }
    header("Location: index.php");
?>