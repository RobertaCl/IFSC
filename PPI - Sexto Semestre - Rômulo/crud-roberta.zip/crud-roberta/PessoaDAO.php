<?php
    include_once "Pessoa.php";
    class PessoaDAO{

        function conectaDB(){
            $conPDO = new PDO("mysql:host=127.0.0.1;dbname=meudb", "root", "aluno");
        
            if(!$conPDO){
                echo "Erro na conexao!";
                return null;
            }
            return $conPDO;
        }

        function pesquisar_pessoas($nome){
            $pessoas = array();
            $conPDO = $this->conectaDB();
        
            $sql = "SELECT * FROM pessoas WHERE LOWER(nome) LIKE LOWER('%$nome%');";
        
            $query = $conPDO->query($sql)->fetchAll();

            if(!$query){
                return array();
            }

            foreach($query as $row){
                $pessoa = new Pessoa($row["nome"], $row["telefone"], $row["email"], $row["data_nasc"]);
                $pessoa->set_id($row["id"]);
                array_push($pessoas, $pessoa);
            }
        
            return $pessoas;
        }
        
        function get_pessoa($id){
            $conPDO = $this->conectaDB();
        
            $sql = "SELECT * FROM pessoas WHERE id=$id;";
        
            $query = $conPDO->query($sql);
        
            if(!$query){
                return array();
            }
            
            $data = $query->fetch();

            $pessoa = new Pessoa($data["nome"], $data["telefone"], $data["email"], $data["data_nasc"]);
            $pessoa->set_id($data["id"]);

            return $pessoa;
        }

        function cadastrar_pessoa($nome, $telefone, $email, $data_nasc){
            $conPDO = $this->conectaDB();

            $sql = "INSERT INTO pessoas VALUES (id, '$nome', '$telefone', '$email', '$data_nasc');";
            $query = $conPDO->query($sql);
            
            if(!$query){
                echo 'Erro ao inserir dados na tabela';
                return false;
            }
        
            return true;
        }

        function alterar_pessoa($id, $nome, $telefone, $email, $data_nasc){
            $conPDO = $this->conectaDB();
            $sql = "UPDATE pessoas SET nome='$nome', telefone='$telefone', email='$email', data_nasc='$data_nasc' WHERE id=$id;";
        
            $query = $conPDO->query($sql);
        
            if(!$query){
                echo 'Erro ao inserir dados na tabela';
                return false;
            }
        
            return true;
        }
        
        function excluir_pessoa($id) {
            $conPDO = $this->conectaDB();
        
            $sql = "DELETE FROM pessoas WHERE id=$id;";
        
            $query = $conPDO->query($sql);
        
            if(!$query){
                echo 'Erro ao deletar dados na tabela';
                return false;
            }
        
            return true;
        }

        function listar_pessoas() {
            $pessoas = array();
            $conPDO = $this->conectaDB();
        
            $sql = "SELECT * FROM pessoas;";
        
            $query = $conPDO->query($sql)->fetchAll();

            if(!$query){
                return array();
            }

            foreach($query as $row){
                $pessoa = new Pessoa($row["nome"], $row["telefone"], $row["email"], $row["data_nasc"]);
                $pessoa->set_id($row["id"]);
                array_push($pessoas, $pessoa);
            }
        
            return $pessoas;
        }
    }
?>