<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/style.css">
    <title> Cadastro </title>
    <script>
        function voltar(){
            window.location.href = "index.php";
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="container-cad">
            <div class="cadastro">
                <div class="cadastroF">
                    <span class="cadastroT">
                        Cadastro
                    </span>

                    <form action="" method="POST" class="blocos" id="formulario">
                        <div class="wrap-input margin-top-35 margin-bottom-35">
                            <label class="label" for="nome"> Nome </label>
                            <input class="input-form" type="text" name="nome" autocomplete="off">
                        </div>

                        <div class="wrap-input margin-bottom-35">
                            <label class="label" for="data_nasc"> Data de Nascimento </label>
                            <input class="input-form" type="date" name="data_nasc" autocomplete="off">
                        </div>

                        <div class="wrap-input margin-bottom-35">
                            <label class="label" for="email"> E-mail </label>
                            <input class="input-form" type="text" name="email" autocomplete="off">
                        </div>

                        <div class="wrap-input margin-bottom-35">
                            <label class="label" for="telefone"> Telefone </label>
                            <input class="input-form" type="tel" name="telefone" autocomplete="off">
                        </div>
                        
                        <div class="container-cadastroBTN">
                            <input type="submit" value="Salvar" form="formulario" class="cadastroF-btnV">
                        </div>
                    </form>

                    <?php
                        session_start();
                        if (!isset($_SESSION["islogged"]) || $_SESSION["islogged"] != "ok"){
                            header("Location: login.php");
                        }
                        include_once "PessoaController.php";
                        if ($_SERVER["REQUEST_METHOD"] == "POST"){
                            if(isset($_POST["nome"]) && isset($_POST["telefone"]) && isset($_POST["email"]) && isset($_POST["data_nasc"])){
                                $controller = new PessoaController();
                                $controller->cadastrar_pessoa($_POST["nome"], $_POST["telefone"], $_POST["email"], $_POST["data_nasc"]);
                                header("Location: index.php");
                            }else{
                                header("Location: cadastrar.php");
                            }
                        }  
                    ?>

                    <div class="container-cadastroBTN">
                        <button onclick="voltar()" class="cadastroF-btnV">
                            Retomar a listagem
                        </button>
                    </div>
                </div>
            </div>
        </div>  
    </div>
    
</body>
</html>