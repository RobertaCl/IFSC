<!DOCTYPE html>
<html lang="pt-br">

<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="CSS/main.css">
</head>

<body>

    <div class="container">
        <div class="container-login">
            <div class="loginW">
                <form class="loginF" action="autenticacao.php" method="POST">
                    <span class="loginFTitulo">
                        Faça seu login
                    </span>

                    <form action="autenticacao.php" method="POST">
                        <div class="wrap-input margin-top-35 margin-bottom-35">
                            <input class="input-form" type="text" name="email" id="email">
                            <span class="focus-input-form" data-placeholder="E-mail"></span>
                        </div>

                        <div class="wrap-input margin-bottom-35">
                            <input class="input-form" type="password" name="password" id="password">
                            <span class="focus-input-form" data-placeholder="Senha"></span>
                        </div>
                        <input class="loginF-btn" type="submit" value="login">
                    </form>

                </form>
            </div>
        </div>
    </div>

</body>

</html>