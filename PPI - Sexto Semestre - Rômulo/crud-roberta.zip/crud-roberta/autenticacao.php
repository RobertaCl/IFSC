<?php
    if (isset($_POST["email"]) && isset($_POST["password"])) {
        if ($_POST["email"] == "root" && $_POST["password"] == "aluno") {
            session_start();
            $_SESSION["islogged"] = "ok";
            header("Location: index.php");
        } else {
            header("Location: login.php");
        }
    } else {
        header("Location: login.php");
    }
    ?>