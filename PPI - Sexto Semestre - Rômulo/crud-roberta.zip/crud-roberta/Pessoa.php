<?php
    class Pessoa{
        private $id;
        private $nome;
        private $telefone;
        private $email;
        private $data_nasc;

        function __construct($nome, $telefone, $email, $data_nasc){
            $this->nome = $nome;
            $this->telefone = $telefone;
            $this->email = $email;
            $this->data_nasc = $data_nasc;
        }

        function get_id(){
            return $this->id;
        }

        function get_nome(){
            return $this->nome;
        }

        function get_telefone(){
            return $this->telefone;
        }

        function get_email(){
            return $this->email;
        }

        function get_data_nasc(){
            return $this->data_nasc;
        }

        function set_id($id){
            $this->id = $id;
        }

        function set_nome($nome){
            $this->nome = $nome;
        }

        function set_telefone($telefone){
            $this->telefone = $telefone;
        }

        function set_email($email){
            $this->email = $email;
        }

        function set_data_nasc($data_nasc){
            $this->data_nasc = $data_nasc;
        }

    }
?>